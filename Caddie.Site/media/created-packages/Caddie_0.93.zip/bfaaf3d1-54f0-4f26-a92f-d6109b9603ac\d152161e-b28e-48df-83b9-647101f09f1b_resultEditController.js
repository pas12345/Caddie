﻿angular
    .module("umbraco")
    .controller("ResultEditController",
                    ["$scope"
                         , "$log"
                         , "$filter"
                         , "resultResource"
                        , ResultEditController]);

function ResultEditController($scope, $log, $filter, resultResource) {
    $logdebug('ResultEditController');
    $log.debug('match: ' + $scope.matchId);

    resultResource.getRegistrations($scope.matchId).then(function (response) {
        $log.debug('resultResource.registrations');
        $scope.results = response.data;
    }, function (reason) {
        $log.debug('resultResource.registrations failed');
        $scope.message = reason;
    });

    //matchResource.getMatch($scope.vm.matchId).then(function (response) {
    //    $log.debug('matchResource.getMatch');
    //    $scope.vm.match = response.data;
    //    $scope.vm.matchText = $scope.vm.match.CourseText + ', Par: ' + $scope.vm.match.Par + ', ' + $scope.vm.match.Matchform;
    //    $log.debug('matchResource.getMatch slut');
    //}, function (reason) {
    //    $log.debug('matchResource.get failed');
    //    $scope.vm.message = reason;
    //});

    //$scope.PlayerChange = function (value) {
    //    $log.debug('PlayerChange: ' + value);
    //    $scope.vm.vgcNo = value;
    //    $scope.GetResult(value);
    //}

    //$scope.submit = function () {
    //    $scope.vm.message = null;
    //    $log.debug('submit: ' + $scope.vm.result.Id);
    //    if ($scope.vm.result.Id) {
    //        $log.debug('submit update: ' + $scope.vm.result.Id);
    //        //$scope.vm.result.$update({ id: $scope.vm.result.Id },
    //        //    function (data) {
    //        //        $scope.vm.message = "... Save Complete";
    //        //    },
    //        //    function (reason) {
    //        //        $scope.vm.message = reason;
    //        //    })
    //    }
    //    else {
    //        $log.debug('submit save: ');
    //        //$scope.vm.result.$save(
    //        //    function (data) {
    //        //        $scope.vm.originalresult = angular.copy(data);
    //        //        $scope.vm.message = "... Save Complete";
    //        //    },
    //        //    function (reason) {
    //        //        $scope.vm.message = reason;
    //        //    })
    //    }
    //};

    //$scope.onBruttoChanged = function () {
    //    if ($scope.vm.result.isHallington)
    //        $scope.vm.result.netto = $scope.vm.result.brutto == null ? null : $scope.vm.result.brutto + $scope.vm.result.hcp;
    //    if ($scope.vm.result.isStrokePlay)
    //        $scope.vm.result.netto = $scope.vm.result.brutto == null ? null : $scope.vm.result.brutto - $scope.vm.result.hcp;
    //}
    //$scope.close = function () {
    //    $location.path("/results");
    //};


    //$scope.GetResult = function (vgcNo) {
    //    $log.debug('GetResult: ' + vgcNo);
    //    $scope.vm.message = null;
    //    resultResource.getPlayerResults($scope.vm.matchId, vgcNo)
    //        .then(function (response) {
    //            $scope.vm.result = response.data;
    //            $scope.vm.originalresult = $scope.vm.result;
    //            $scope.vm.showPut = $scope.vm.result.IsStrokePlay;
    //            $scope.vm.showBruttoNetto = $scope.vm.result.IsStrokePlay || $scope.vm.result.IsHallington;
    //        }, function (reason) {
    //            $log.debug("registration failed " + reason);
    //            $scope.vm.message = reason;
    //        })
    //};
};