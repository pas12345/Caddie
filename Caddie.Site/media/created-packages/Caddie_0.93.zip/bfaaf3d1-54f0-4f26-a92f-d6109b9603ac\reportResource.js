﻿
angular.module("umbraco.resources").factory("reportResource",

    function ($http, $cookieStore) {
        return {
            printMatchRegistration: function (matchId) {
                var data = { 'matchId': matchId };
                return $http({
                    method: 'get',
                    url: this.getApiPath() + "MatchRegistrationReport?matchId=" + matchId,
                    headers: {
                        'Content-type': 'application/pdf',
                    },
                    responseType: 'arraybuffer'
                });
            },
            printMatchResult: function (matchId) {
                return $http({
                    method: 'post', url: this.getApiPath() + "MatchResultReport",
                    params: { 'matchId': matchId },
                    headers: {
                        'Content-type': 'application/pdf',
                    },
                    responseType: 'arraybuffer'
                });
            },
            printTourRegistration: function (tourId) {
                return $http({
                    method: 'get',
                    url: this.getApiPath() + "TourRegistrationReport?tourId="+tourId,
                    headers: {
                        'Content-type': 'application/pdf',
                    },
                    responseType: 'arraybuffer'
                });
            },
            getApiPath: function () {
                return Umbraco.Sys.ServerVariables["caddie"]["ReportApiUrl"];
            }

        };
    });
