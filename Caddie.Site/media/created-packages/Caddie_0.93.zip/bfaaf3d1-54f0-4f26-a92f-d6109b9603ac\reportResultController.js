﻿'use strict';
angular
    .module("umbraco")
    .controller("ReportResultController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "matchResource"
                         , "reportResource"
                        , ReportResultController]);

function ReportResultController($scope, $log, $location, $filter, $routeParams, matchResource, reportResource) {

    $log.debug('ReportResultController loaded');

    $scope.match = {};
    $scope.matches = null;

    matchResource.getMatchesBefore().then(function (response) {
        $log.debug('matchResource.getMatchesBefore');
        $scope.matches = response.data;
       $log.debug($scope.matches);
        $scope.match = $scope.matches[0];
    }, function (reason) {
        $log.debug('matchResource.getMatchesBefore failed');
        $scope.message = reason;
    });
    
    $scope.MatchChange = function () {
        $log.debug($scope.match.Id);
        matchResource.getMatch($scope.match.Id).then(function (response) {
            $scope.match = response.data;
            $log.debug($scope.match);
        }, function (reason) {
            $log.debug('matchResource.getMatch failed');
            $scope.message = reason;
        });
    }

    $scope.Print = function () {
        $scope.message = "Udskriften bliver nu dannet og downloadet";
        reportResource.printMatchResult($scope.match.Id).then(function (response) {
            $scope.message = "Så er udskriften downloadet";
        }, function (reason) {
            $scope.message = "Udskrift fejlede: " + reason;
        });
    };
};