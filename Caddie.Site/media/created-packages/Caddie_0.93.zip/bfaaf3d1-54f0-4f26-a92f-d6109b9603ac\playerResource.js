﻿
angular.module("umbraco.resources").factory("playerResource",

    function ($http, $cookieStore) {
        return {
            getMember: function (id) {
                return $http.get(this.getApiPath() + "GetMember?id=" + id);
            },
            getPlayer: function (id) {
                return $http.get(this.getApiPath() + "GetPlayer?vgcNo=" + id);
            },
            getNonMemberList: function () {
                return $http.get(this.getApiPath() + "GetNonMemberList");
            },
            save: function (object) {
                return $http.post(this.getApiPath() + "Save", object);
            },
            getApiPath: function () {
                return Umbraco.Sys.ServerVariables["caddie"]["PlayerApiUrl"];
            }
        };
    });
