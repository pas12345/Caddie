﻿'use strict';
angular
    .module("umbraco")
    .controller("PlayerHcpController",
                    ["$scope"
                    , "$log"
                    , "playerResource"
                    , "notificationsService"
                    , PlayerHcpController]);

function PlayerHcpController($scope, $log, playerResource, notificationsService) {
    $scope.getUpdatedHcp = function () {
        playerResource.getUpdatedHcp().then(function (response) {
            $scope.message = 'Hcp opdateret';
            notificationsService.success("Success", "Oplysningerne er opdateret");
        }, function (reason) {
            $log.debug('playerResource.getUpdatedHcp failed');
            $log.debug(reason);
            notificationsService.error("Der opstod en fejl i opdateringen: ", reason);
        });
    }
};