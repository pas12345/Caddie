﻿angular
    .module("umbraco")
    .controller("ResultEditController",
                    ["$scope"
                         , "$log"
                         , "$filter"
                         , "$routeParams"
                         , "resultResource"
                         , "notificationsService"
                         , ResultEditController]);

function ResultEditController($scope, $log, $filter, $routeParams, resultResource, notificationsService) {
    $log.debug('ResultEditController');
    $scope.matchId = $routeParams.id;
    $scope.test = "mystring";

    $scope.settleMatch = function (id) {
        $log.debug('SettleMatch:' + id);
        resultResource.settleMatch(id).then(function (response) {
            $log.debug('SettleMatch' + id);
            notificationsService.success("Succes", "Matchen er opgjort og point er tildelt");
        }, function (reason) {
            $log.debug('SettleMatch failed: ' + id);
            $log.debug(reason);
            notificationsService.error("Det var ikke muligt at lukke matchen", error.Message);
        });
    }

};