﻿
angular.module("umbraco.resources").factory("resultResource",

    function ($http, $cookieStore) {
        return {
            getRegistrations: function (matchId) {
                return $http.get(this.getApiPath() + "GetRegistrations?matchId=" + matchId);
            },
            getPlayerResults: function (matchId, vgcNo) {
                return $http.get(this.getApiPath() + "GetPlayerResults?matchId=" + matchId + "&vgcNo=" + vgcNo);
            },
            getCompetitions: function () {
                return $http.get(this.getApiPath() + "GetCompetitions");
            },
            getCompetitionResult: function (matchId, competitionId) {
                return $http.get(this.getApiPath() + "GetCompetitionResult?matchId=" + matchId + "&competitionId=" + competitionId);
            },
            getCompetitionResultById: function (id) {
                return $http.get(this.getApiPath() + "GetCompetitionResultById?id=" + id);
            },
            getPinResultById: function (id) {
                return $http.get(this.getApiPath() + "GetPar3Result?id=" + id);
            },
            save: function (object) {
                return $http.post(this.getApiPath() + "SaveResult", object);
            },
            savePinResult: function (object) {
                return $http.post(this.getApiPath() + "SavePinResult", object);
            },
            saveCompetitionResult: function (object) {
                return $http.post(this.getApiPath() + "SaveCompetitionResult", object);
            },
            delete: function (id) {
                return $http.post(this.getApiPath() + "DeleteResult", id);
            },
            settleMatch: function (object) {
                return $http.post(this.getApiPath() + "SettleMatch", object);
            },
            getApiPath: function () {
                return Umbraco.Sys.ServerVariables["caddie"]["ResultApiUrl"];
            }

        };
    });
