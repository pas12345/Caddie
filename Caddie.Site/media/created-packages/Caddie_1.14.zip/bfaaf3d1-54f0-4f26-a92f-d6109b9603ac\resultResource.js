﻿
angular.module("umbraco.resources").factory("resultResource",

    function ($http, $cookieStore) {
        return {
            getRegistrations: function (matchId) {
                return $http.get(this.getApiPath() + "GetRegistrations?matchId=" + matchId);
            },
            getPlayerResults: function (matchId, vgcNo) {
                return $http.get(this.getApiPath() + "GetPlayerResults?matchId=" + matchId +"&vgcNo=" + vgcNo);
            },
            save: function (object) {
                return $http.post(this.getApiPath() + "SaveResult", object);
            },
            delete: function (id) {
                return $http.post(this.getApiPath() + "DeleteResult", id);
            },
            settleMatch: function (object) {
                return $http.post(this.getApiPath() + "SettleMatch", object);
            },
            getApiPath: function () {
                return Umbraco.Sys.ServerVariables["caddie"]["ResultApiUrl"];
            }

        };
    });
