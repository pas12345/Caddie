﻿'use strict';
angular
    .module("umbraco")
    .controller("CourseEditController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "courseResource"
                        , CourseEditController]);

function CourseEditController($scope, $log, $location, $filter, $routeParams, courseResource) {

    $log.debug('CourseEditController loaded');

    $scope.course = {
        id: 0, 
        name: null,
        tees:[]
    };
    $scope.club.id = $routeParams.id;

    //courseResource.getClub($scope.club.id).then(function (response) {
    //    $log.debug('courseResource.getClub');
    //    $scope.club.name = response.data.StringValue;
    //}, function (reason) {
    //    $log.debug('courseResource.get getClub');
    //    $scope.message = reason;
    //});

    //courseResource.getCourses($scope.club.id).then(function (response) {
    //    $log.debug('courseResource.getCourses');
    //    $scope.club.courses = response.data;
    //}, function (reason) {
    //    $log.debug('courseResource.getCourses failed');
    //    $scope.message = reason;
    //});


    $scope.editCourse = function (id) {
        dialogService.closeAll();
        dialogService.open({
            template: '/app_plugins/Caddie/backoffice/CourseTree/dialogs/edit.html',
            id: id,
            closeOnSave: true,
            //tabFilter: ["Generic properties"],
            callback: function (data) {
                $scope.reloadView();
            }
        });
    };

    //$scope.PlayerChange = function () {
    //    $log.debug($scope.selectedVgcNo);
    //    //$log.debug('PlayerChange: ' + $scope.selectedVgcNo);
    //    //$scope.vgcNo = $scope.selectedVgcNo;
    //    //$scope.GetResult($scope.vgcNo);
    //}

    //$scope.submit = function () {
    //    $scope.message = null;
    //    $log.debug('submit: ' + $scope.result.Id);
    //    if ($scope.result.Id) {
    //        $log.debug('submit update: ' + $scope.result.Id);
    //        //$scope.result.$update({ id: $scope.result.Id },
    //        //    function (data) {
    //        //        $scope.message = "... Save Complete";
    //        //    },
    //        //    function (reason) {
    //        //        $scope.message = reason;
    //        //    })
    //    }
    //    else {
    //        $log.debug('submit save: ');
    //        //$scope.result.$save(
    //        //    function (data) {
    //        //        $scope.originalresult = angular.copy(data);
    //        //        $scope.message = "... Save Complete";
    //        //    },
    //        //    function (reason) {
    //        //        $scope.message = reason;
    //        //    })
    //    }
    //};

    //$scope.onBruttoChanged = function () {
    //    if ($scope.result.isHallington)
    //        $scope.result.netto = $scope.result.brutto == null ? null : $scope.result.brutto + $scope.result.hcp;
    //    if ($scope.result.isStrokePlay)
    //        $scope.result.netto = $scope.result.brutto == null ? null : $scope.result.brutto - $scope.result.hcp;
    //}
    //$scope.close = function () {
    //    $location.path("/results");
    //};


    //$scope.GetResult = function (vgcNo) {
    //    $log.debug('GetResult: ' + vgcNo);
    //    $scope.message = null;
    //    courseResource.getPlayerResults($scope.matchId, vgcNo)
    //        .then(function (response) {
    //            $scope.result = response.data;
    //            $scope.originalresult = $scope.result;
    //            $scope.hcpText = "Hcp: " + $scope.result.Hcp + " (" + $scope.result.HcpIndex + ")";
    //        }, function (reason) {
    //            $log.debug("registration failed " + reason);
    //            $scope.message = reason;
    //        })
    //};

};