﻿
angular.module("umbraco.resources").factory("matchplayResource",

    function ($http, $cookieStore) {
        return {
            getMatch: function (matchId) {
                return $http.get(this.getApiPath() + "GetMatch?matchId=" + matchId);
            },
            getMatches: function (id) {
                return $http.get(this.getApiPath() + "GetMatches?leagueId=" + id);
            },
            save: function (object) {
                return $http.post(this.getApiPath() + "SaveMatchplayResult", object);
            },
            getApiPath: function() {
                return Umbraco.Sys.ServerVariables["caddie"]["MatchplayApiUrl"];
            }

        };
    });
