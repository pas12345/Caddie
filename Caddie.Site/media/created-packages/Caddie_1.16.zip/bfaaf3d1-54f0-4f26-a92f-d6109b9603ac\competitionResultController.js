﻿'use strict';
angular
    .module("umbraco")
    .controller("CompetitionResultController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "resultResource"
                         , "playerResource"
                         , "notificationsService"
                        , CompetitionResultController]);

function CompetitionResultController($scope, $log, $location, $filter, $routeParams, resultResource, playerResource, notificationsService) {

    $log.debug('CompetitionResultController');
    $scope.id = $routeParams.id;

    playerResource.getMemberNames(2016).then(function (response) {
        $scope.players = response.data;
    }, function (reason) {
        $log.debug('playerResource.getMemberList failed');
        $scope.message = reason;
    });

    resultResource.getCompetitions().then(function (response) {
        $scope.competitions = response.data;
    }, function (reason) {
        $log.debug('resultResource.getCompetitions failed');
        $scope.message = reason;
    });

    if ($scope.id < 0) {
        $scope.result = {
            MatchId: -1 * $routeParams.id
        };
    } else {
        resultResource.getCompetitionResultById($scope.id).then(function (response) {
            $log.debug("getCompetitionResultById(" + $scope.id + ")");
            $log.debug(response.data);
            $scope.result = response.data;
        },
        function (reason) {
            $scope.message = reason;
            notificationsService.error("Data blev ikke opdateret", error.Message);
        })
    }

    $scope.GetCompetitionResult = function () {
        resultResource.getCompetitionResult($scope.result.MatchId, $scope.result.CompetitionId).then(function (response) {
            $log.debug("getcompetitionResult(" + $scope.result.MatchId + "," + $scope.result.CompetitionId + ")");
            $log.debug(response.data);
            $scope.result = response.data;
        },
        function (reason) {
            $scope.message = reason;
            notificationsService.error("Data blev ikke opdateret", error.Message);
        })
    }

    $scope.competitionChange = function () {
        GetCompetitionResult();
    }

    $scope.submit = function () {
        $scope.message = null;
        $log.debug('submit: ');
        resultResource.saveCompetitionResult($scope.result).then(function (response) {
            $scope.message = "... resultatet er gemt";
            navigationService.syncTree({ tree: 'resultTree', path: [-1, -1], forceReload: true });
            notificationsService.success("Success", "Resultatet er blevet gemt");
        },
        function (reason) {
            $scope.message = reason;
            notificationsService.error("Data blev ikke opdateret", error.Message);
        })
        }

    $scope.close = function () {
        $location.path("/results");
    };
};