﻿'use strict';
angular
    .module("umbraco")
    .controller("MatchplayEditMatchController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "matchplayResource"
                         , "notificationsService"
                        , MatchplayEditMatchController]);

function MatchplayEditMatchController($scope, $log, $location, $filter, $routeParams, matchplayResource, notificationsService) {

    $scope.leagueId = 1; //$routeParams.id;
    $log.debug($scope.leagueId);

    $scope.teams1 = {};
    $scope.teams2 = {};
    $scope.matchText = 'Række: A';
    if ($scope.league == 2) {
        $scope.matchText = 'Række: B';
    }
    else if ($scope.league == 3) {
        $scope.matchText = 'Række: Par';
    }
    $scope.matchText = '';

    $scope.leagues = [
        { Id: 1, StringValue: 'Række: A' },
        { Id: 2, StringValue: 'Række: B' },
        { Id: 3, StringValue: 'Række: Par' }
    ];

    $scope.leagueChange = function () {
        $log.debug($scope.match.LeagueId);
        matchplayResource.getTeams($scope.match.LeagueId).then(function (response) {
            $scope.teams1 = response.data;
            $scope.teams2 = response.data;
            $log.debug($scope.matches);
        }, function (reason) {
            $log.debug('matchplayResource.getTeams failed');
            $scope.message = reason;
        })
    };

    $scope.submit = function () {
        $scope.message = null;
        //$scope.match.LeagueId = $scope.leagueId;
        matchplayResource.saveMatch($scope.match).then(function (response) {
            notificationsService.success("Success", "Ændringerne er gemt");
        },
        function (reason) {
            $scope.message = reason.data.ExceptionMessage;
            notificationsService.error("Data blev ikke opdateret", error.Message);
        })
    };

};