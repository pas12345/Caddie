﻿'use strict';
angular
    .module("umbraco")
    .controller("MatchplayEditMatchController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "matchplayResource"
                         , "notificationsService"
                        , MatchplayEditMatchController]);

function MatchplayEditMatchController($scope, $log, $location, $filter, $routeParams, matchplayResource, notificationsService) {

    $scope.match = {};
    $scope.match.LeagueId = 0;
    $scope.teams1 = {};
    $scope.teams2 = {};

    $scope.leagues = [
        { Id: 1, StringValue: 'Række: A' },
        { Id: 2, StringValue: 'Række: B' },
        { Id: 3, StringValue: 'Række: Par' }
    ];

    $log.debug($routeParams);

    $scope.getTeams = function (id) {
        $log.debug('getTeams');
        $log.debug(id);
        matchplayResource.getTeams(id).then(function (response) {
            $scope.teams1 = response.data;
            $scope.teams2 = response.data;
        }, function (reason) {
            $log.debug('matchplayResource.getTeams failed');
            $scope.message = reason.data.ExceptionMessage;
        })
        $scope.matchText = 'Række: A';
        if (id == 2) {
            $scope.matchText = 'Række: B';
        }
        else if (id == 3) {
            $scope.matchText = 'Række: Par';
        }
    };

    $scope.LeagueChange = function () {
        $log.debug('leagueChanged');
        $log.debug($scope.leagueId);
        $scope.getTeams($scope.leagueId);
    };

    $log.debug($routeParams.id);
    if ($routeParams.id > 0)
    {
        $log.debug('getMatch');
        matchplayResource.getMatch($routeParams.id).then(function (response) {
            $scope.match = response.data;
            $log.debug($scope.match);
            $scope.LeagueId = $scope.match.LeagueId;
            $scope.getTeams($scope.LeagueId);
        }, function (reason) {
            $log.debug('matchplayResource.getMatch failed');
            $scope.message = reason.data.ExceptionMessage;
        });
    }

    $scope.submit = function () {
        $scope.message = null;
        $scope.match.LeagueId = $scope.leagueId;
        matchplayResource.saveMatch($scope.match).then(function (response) {
            notificationsService.success("Success", "Ændringerne er gemt");
        },
        function (reason) {
            $scope.message = reason;
            notificationsService.error("Data blev ikke opdateret", error.Message);
        })
    };
};