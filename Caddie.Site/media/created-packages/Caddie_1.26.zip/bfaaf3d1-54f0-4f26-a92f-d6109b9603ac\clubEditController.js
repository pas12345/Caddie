﻿'use strict';
angular
    .module("umbraco")
    .controller("ClubEditController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "courseResource"
                        , ClubEditController]);

function ClubEditController($scope, $log, $location, $filter, $routeParams, courseResource) {

    $log.debug('ClubEditController loaded');
    $log.debug($routeParams);

    $scope.clubName = {};

    $scope.submit = function () {
        $scope.message = null;
        courseResource.updateClub($scope.clubName).then(function (response) {
            notificationsService.success("Success", "Ændringerne er gemt");
        },
        function (reason) {
            $scope.message = reason.data.Message;
            $log.debug(reason.data);
            notificationsService.error("Data blev ikke opdateret", error.Message);
        })
    };
};