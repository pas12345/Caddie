﻿
angular.module("umbraco.resources").factory("tourResource",

    function ($http, $cookieStore) {
        return {
            getTour: function (tourId) {
                return $http.get(this.getApiPath() + "GetTour?tourId=" + tourId);
            },
            getTours: function () {
                return $http.get(this.getApiPath() + "GetTourItems");
            },
            getApiPath: function () {
                return Umbraco.Sys.ServerVariables["caddie"]["TourApiUrl"];
            }

        };
    });
