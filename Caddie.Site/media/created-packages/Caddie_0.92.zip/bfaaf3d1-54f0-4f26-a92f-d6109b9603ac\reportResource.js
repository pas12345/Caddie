﻿
angular.module("umbraco.resources").factory("reportResource",

    function ($http, $cookieStore) {
        return {
            printMatchRegistration: function (matchId) {
                return $http.post(this.getApiPath() + "MatchRegistrationReport", matchId);
            },
            printMatchResult: function (matchId) {
                return $http.get(this.getApiPath() + "MatchResultReport?matchId=" + matchId);
            },
            printTourRegistration: function (tourId) {
                return $http.get(this.getApiPath() + "TourRegistrationReport?tourId=" + tourId);
            },
            getApiPath: function () {
                return Umbraco.Sys.ServerVariables["caddie"]["ReportApiUrl"];
            }

        };
    });
