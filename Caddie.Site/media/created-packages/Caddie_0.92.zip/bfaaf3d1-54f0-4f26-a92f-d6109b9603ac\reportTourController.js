﻿'use strict';
angular
    .module("umbraco")
    .controller("ReportTourController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "tourResource"
                         , "reportResource"
                        , ReportTourController]);

function ReportTourController($scope, $log, $location, $filter, $routeParams, tourResource, reportResource) {

    $log.debug('reportTourController loaded');

    $scope.tour = {};
    $scope.tours = null;
    $scope.tourText = 'Første text';
    $scope.selectedTourId = 0;

    tourResource.getTours().then(function (response) {
        $log.debug('tourResource.getTours');
        $scope.tours = response.data;
        $scope.tour = $scope.tours[0];
    }, function (reason) {
        $log.debug('tourResource.getTours failed');
        $scope.message = reason;
    });

    $scope.tourChange = function () {
        $log.debug($scope.tour.Id);
        matchResource.getTour($scope.tour.Id).then(function (response) {
            $scope.tour = response.data;
            $log.debug($scope.tour);
        }, function (reason) {
            $log.debug('matchResource.getTour failed');
            $scope.message = reason;
        });
    }

    $scope.Print = function () {
        $scope.message = "Udskriften bliver nu dannet og downloadet";
        reportResource.printTourRegistration($scope.tour.Id).then(function (response) {
            $scope.message = "Så er udskriften downloadet";
        }, function (reason) {
            $scope.message = "Udskrift fejlede: " + reason;
        });
    };
};