﻿
angular.module("umbraco.resources").factory("courseResource",

    function ($http, $cookieStore) {
        return {
            getClub: function (id) {
                return $http.get(this.getApiPath() + "GetClub?clubId=" + id);
            },
            getCourses: function (id) {
                return $http.get(this.getApiPath() + "GetCourses?clubId=" + id);
            },
            getTees: function () {
                return $http.get(this.getApiPath() + "tees");
            },
            getApiPath: function () {
                return Umbraco.Sys.ServerVariables["caddie"]["CourseApiUrl"];
            }
        };
    });
