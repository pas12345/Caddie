﻿
angular.module("umbraco.resources").factory("tourResource",

    function ($http, $cookieStore) {
        return {
            getTour: function (tourId) {
                return $http.get(this.getApiPath() + "GetTour?tourId=" + tourId);
            },
            getApiPath: function() {
                return Umbraco.Sys.ServerVariables["caddie"]["TourApiUrl"];
            }

        };
    });
