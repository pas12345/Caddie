﻿
angular.module("umbraco.resources").factory("tourResource",

    function ($http, $cookieStore) {
        return {
            getMatch: function (matchId) {
                return $http.get(this.getApiPath() + "GetMatch?matchId=" + matchId);
            },
            matchDates: function () {
                return $http.get(this.getApiPath() + "matchDates");
            },
            lastMatch: function () {
                return $http.get(this.getApiPath() + "lastMatch");
            },
            getApiPath: function() {
                return Umbraco.Sys.ServerVariables["caddie"]["TourApiUrl"];
            }

        };
    });
