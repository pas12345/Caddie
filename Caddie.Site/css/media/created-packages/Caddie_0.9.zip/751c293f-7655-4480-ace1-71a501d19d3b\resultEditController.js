﻿angular
    .module("umbraco")
    .controller("ResultEditController",
                    ["$scope"
                         , "$log"
                         , "$filter"
                         , "resultResource"
                        , ResultEditController]);

function ResultEditController($scope, $log, $filter, resultResource) {
    $logdebug('ResultEditController');
    $log.debug('match: ' + $scope.matchId);

    resultResource.getRegistrations($scope.matchId).then(function (response) {
        $log.debug('resultResource.registrations');
        $scope.results = response.data;
    }, function (reason) {
        $log.debug('resultResource.registrations failed');
        $scope.message = reason;
    });
};