﻿'use strict';
angular
    .module("umbraco")
    .controller("TourController",
                    ["$scope"
                         , "$log"
                         , "$location"
                         , "$filter"
                         , "$routeParams"
                         , "tourResource"
                        , TourController]);

function TourController($scope, $log, $location, $filter, $routeParams, resultResource, matchResource) {

    $log.debug('TourController loaded');

    $scope.matchId = $routeParams.id;
    $scope.hcpText = "-";
    $scope.result = null;
    $scope.selectedVgcNo = 0;

    tourResource.getMatch($scope.matchId).then(function (response) {
        $log.debug('tourResource.getMatch');
        $scope.match = response.data;
        $scope.matchText = $scope.match.CourseText + ', Par: ' + $scope.match.Par + ', ' + $scope.match.Matchform;
        $scope.showPut = $scope.match.IsStrokePlay;
        $scope.showBruttoNetto = $scope.match.IsStrokePlay || $scope.match.IsHallington;
        $log.debug('tourResource.getMatch slut');
    }, function (reason) {
        $log.debug('tourResource.get failed');
        $scope.message = reason;
    });
    
    resultResource.getRegistrations($scope.matchId).then(function (response) {
        $log.debug('resultResource.registrations');
        $scope.results = response.data;
    }, function (reason) {
        $log.debug('resultResource.registrations failed');
        $scope.message = reason;
    });

    $scope.PlayerChange = function () {
        $log.debug($scope.selectedVgcNo);
        //$log.debug('PlayerChange: ' + $scope.selectedVgcNo);
        //$scope.vgcNo = $scope.selectedVgcNo;
        //$scope.GetResult($scope.vgcNo);
    }

    $scope.submit = function () {
        $scope.message = null;
        $log.debug('submit: ' + $scope.result.Id);
        if ($scope.result.Id) {
            $log.debug('submit update: ' + $scope.result.Id);
            //$scope.result.$update({ id: $scope.result.Id },
            //    function (data) {
            //        $scope.message = "... Save Complete";
            //    },
            //    function (reason) {
            //        $scope.message = reason;
            //    })
        }
        else {
            $log.debug('submit save: ');
            //$scope.result.$save(
            //    function (data) {
            //        $scope.originalresult = angular.copy(data);
            //        $scope.message = "... Save Complete";
            //    },
            //    function (reason) {
            //        $scope.message = reason;
            //    })
        }
    };

    $scope.onBruttoChanged = function () {
        if ($scope.result.isHallington)
            $scope.result.netto = $scope.result.brutto == null ? null : $scope.result.brutto + $scope.result.hcp;
        if ($scope.result.isStrokePlay)
            $scope.result.netto = $scope.result.brutto == null ? null : $scope.result.brutto - $scope.result.hcp;
    }
    $scope.close = function () {
        $location.path("/results");
    };


    $scope.GetResult = function (vgcNo) {
        $log.debug('GetResult: ' + vgcNo);
        $scope.message = null;
        resultResource.getPlayerResults($scope.matchId, vgcNo)
            .then(function (response) {
                $scope.result = response.data;
                $scope.originalresult = $scope.result;
                $scope.hcpText = "Hcp: " + $scope.result.Hcp + " (" + $scope.result.HcpIndex + ")";
            }, function (reason) {
                $log.debug("registration failed " + reason);
                $scope.message = reason;
            })
    };

};